from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from app import db
from models import Loan
import os
from datetime import datetime

business_bp = Blueprint('business', __name__)

@business_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.user_type != 'business':
        return "Unauthorized", 403
    loans = Loan.query.filter_by(business_id=current_user.id).order_by(Loan.created_at.desc()).all()
    return render_template('business/dashboard.html', loans=loans)

@business_bp.route('/kyb', methods=['GET', 'POST'])
@login_required
def kyb():
    if request.method == 'POST':
        try:
            # Update business details
            current_user.business_name = request.form.get('business_name')
            current_user.cin = request.form.get('cin')
            current_user.din = request.form.get('din')
            current_user.fssai = request.form.get('fssai')
            current_user.uaadhar = request.form.get('uaadhar')
            current_user.business_pan = request.form.get('business_pan')
            current_user.gst = request.form.get('gst')
            current_user.tan = request.form.get('tan')
            current_user.linkedin_id = request.form.get('linkedin_id')
            current_user.kyb_submitted_at = datetime.utcnow()
            current_user.kyb_status = 'pending_review'

            # Handle document uploads
            if 'business_docs' in request.files:
                docs = request.files.getlist('business_docs')
                doc_paths = []
                for doc in docs:
                    if doc:
                        filename = f'business_doc_{current_user.id}_{len(doc_paths)}.pdf'
                        doc_path = os.path.join('uploads', filename)
                        doc.save(doc_path)
                        doc_paths.append(doc_path)

                current_user.business_docs_path = ','.join(doc_paths)

            db.session.commit()
            return jsonify({'status': 'success'})
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500

    return render_template('business/kyb.html')

@business_bp.route('/loan/apply', methods=['GET', 'POST'])
@login_required
def apply_loan():
    if request.method == 'POST':
        try:
            loan_data = {
                'business_id': current_user.id,
                'amount': float(request.form.get('amount')),
                'type': request.form.get('loan_type'),
                'purpose': request.form.get('purpose'),
                'status': 'pending'
            }
            loan = Loan(**loan_data)
            db.session.add(loan)
            db.session.commit()
            return jsonify({'status': 'success'})
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500
    return render_template('business/loan.html')