from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from app import db
from models import User, Transaction
import os
import requests
from datetime import datetime

individual_bp = Blueprint('individual', __name__)

@individual_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.user_type != 'individual':
        return "Unauthorized", 403
    transactions = Transaction.query.filter(
        (Transaction.sender_id == current_user.id) | 
        (Transaction.recipient_id == current_user.id)
    ).order_by(Transaction.timestamp.desc()).all()
    return render_template('individual/dashboard.html', transactions=transactions)

@individual_bp.route('/kyc', methods=['GET', 'POST'])
@login_required
def kyc():
    if request.method == 'POST':
        pan_number = request.form.get('pan_number')
        pan_card = request.files.get('pan_card')
        person_image = request.files.get('person_image')

        if not all([pan_number, pan_card, person_image]):
            return jsonify({'error': 'All fields are required'}), 400

        try:
            # Save files temporarily
            pan_path = os.path.join('uploads', f'pan_{current_user.id}.jpg')
            selfie_path = os.path.join('uploads', f'selfie_{current_user.id}.jpg')

            pan_card.save(pan_path)
            person_image.save(selfie_path)

            # Prepare files for API request
            files = {
                'pan_card': (pan_card.filename, open(pan_path, 'rb'), 'image/jpeg'),
                'person_image': (person_image.filename, open(selfie_path, 'rb'), 'image/jpeg')
            }
            data = {'pan_number': pan_number}

            # Call PAN verification API
            response = requests.post(
                'https://pan-verify-api-app.onrender.com/verify_pan',
                files=files,
                data=data
            )

            verification_result = response.json()

            # Update user data
            current_user.pan_number = pan_number
            current_user.pan_file_path = pan_path
            current_user.photo_file_path = selfie_path
            current_user.pan_verified = verification_result.get('verified', False)
            current_user.pan_verification_response = verification_result
            current_user.kyc_status = 'approved' if verification_result.get('verified', False) else 'rejected'
            current_user.kyc_submitted_at = datetime.utcnow()

            db.session.commit()

            # Clean up temporary files
            for file_handle in files.values():
                file_handle[1].close()

            return jsonify({
                'status': 'success',
                'verification': verification_result
            })
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500
    return render_template('individual/kyc.html')

@individual_bp.route('/transfer', methods=['POST'])
@login_required
def transfer():
    try:
        amount = float(request.form.get('amount'))
        recipient_email = request.form.get('recipient_email')

        recipient = User.query.filter_by(email=recipient_email).first()
        if not recipient:
            return jsonify({'error': 'Recipient not found'}), 404

        if current_user.balance < amount:
            return jsonify({'error': 'Insufficient funds'}), 400

        # Create transaction and update balances
        transaction = Transaction(
            sender_id=current_user.id,
            recipient_id=recipient.id,
            amount=amount
        )

        current_user.balance -= amount
        recipient.balance += amount

        db.session.add(transaction)
        db.session.commit()

        return jsonify({'status': 'success'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500