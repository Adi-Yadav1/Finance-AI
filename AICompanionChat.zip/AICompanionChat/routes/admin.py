from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from app import db
from models import User, Loan, Transaction
from datetime import datetime

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.user_type != 'admin':
        return "Unauthorized", 403

    # Get all users with pending verifications
    pending_kyc = User.query.filter_by(kyc_status='pending_review').all()
    pending_kyb = User.query.filter_by(kyb_status='pending_review').all()
    pending_loans = Loan.query.filter_by(status='pending').all()

    # Get statistics
    total_users = User.query.count()
    total_businesses = User.query.filter_by(user_type='business').count()
    total_individuals = User.query.filter_by(user_type='individual').count()

    # Get loan statistics
    approved_loans = Loan.query.filter_by(status='approved').count()
    rejected_loans = Loan.query.filter_by(status='rejected').count()
    total_loan_amount = db.session.query(db.func.sum(Loan.amount)).filter_by(status='approved').scalar() or 0

    return render_template('admin/dashboard.html',
                         pending_kyc=pending_kyc,
                         pending_kyb=pending_kyb,
                         pending_loans=pending_loans,
                         total_users=total_users,
                         total_businesses=total_businesses,
                         total_individuals=total_individuals,
                         approved_loans=approved_loans,
                         rejected_loans=rejected_loans,
                         total_loan_amount=total_loan_amount)

@admin_bp.route('/database')
@login_required
def view_database():
    if current_user.user_type != 'admin':
        return "Unauthorized", 403

    users = User.query.all()
    loans = Loan.query.all()
    transactions = Transaction.query.all()

    return render_template('admin/database.html',
                         users=users,
                         loans=loans,
                         transactions=transactions)

@admin_bp.route('/kyc/<user_id>', methods=['POST'])
@login_required
def review_kyc(user_id):
    if current_user.user_type != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403

    status = request.form.get('status')
    user = User.query.get(user_id)

    if not user:
        return jsonify({'error': 'User not found'}), 404

    user.kyc_status = status
    user.kyc_verified_at = datetime.utcnow()
    user.kyc_verified_by = current_user.id
    db.session.commit()
    return jsonify({'status': 'success'})

@admin_bp.route('/kyb/<user_id>', methods=['POST'])
@login_required
def review_kyb(user_id):
    if current_user.user_type != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403

    status = request.form.get('status')
    user = User.query.get(user_id)

    if not user:
        return jsonify({'error': 'User not found'}), 404

    user.kyb_status = status
    user.kyb_verified_at = datetime.utcnow()
    user.kyb_verified_by = current_user.id
    db.session.commit()
    return jsonify({'status': 'success'})

@admin_bp.route('/loan/<loan_id>', methods=['POST'])
@login_required
def review_loan(loan_id):
    if current_user.user_type != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403

    status = request.form.get('status')
    rejection_reason = request.form.get('rejection_reason')
    loan = Loan.query.get(loan_id)

    if not loan:
        return jsonify({'error': 'Loan not found'}), 404

    loan.status = status
    if status == 'approved':
        loan.approved_at = datetime.utcnow()
        loan.approved_by = current_user.id
    elif status == 'rejected':
        loan.rejection_reason = rejection_reason

    db.session.commit()
    return jsonify({'status': 'success'})