from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db
from datetime import datetime

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    user_type = db.Column(db.String(20), nullable=False)  # admin, individual, business
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # KYC fields
    kyc_status = db.Column(db.String(20), default='pending')  # pending, pending_review, approved, rejected
    pan_number = db.Column(db.String(10))
    pan_verified = db.Column(db.Boolean, default=False)
    pan_verification_response = db.Column(db.JSON)  # Store API response
    pan_file_path = db.Column(db.String(255))
    photo_file_path = db.Column(db.String(255))
    kyc_submitted_at = db.Column(db.DateTime)
    kyc_verified_at = db.Column(db.DateTime)
    kyc_verified_by = db.Column(db.Integer, db.ForeignKey('user.id'))

    # KYB fields
    kyb_status = db.Column(db.String(20), default='pending')  # pending, pending_review, approved, rejected
    business_name = db.Column(db.String(200))
    cin = db.Column(db.String(21))  # Corporate Identity Number
    din = db.Column(db.String(8))   # Director Identification Number
    fssai = db.Column(db.String(14))
    uaadhar = db.Column(db.String(12))
    business_pan = db.Column(db.String(10))
    gst = db.Column(db.String(15))
    tan = db.Column(db.String(10))  # Tax Deduction Account Number
    linkedin_id = db.Column(db.String(100))
    kyb_submitted_at = db.Column(db.DateTime)
    kyb_verified_at = db.Column(db.DateTime)
    kyb_verified_by = db.Column(db.Integer, db.ForeignKey('user.id'))

    # Business documents
    business_docs_path = db.Column(db.String(255))

    # Financial data
    balance = db.Column(db.Float, default=0.0)

    # Relationships
    transactions_sent = db.relationship('Transaction', foreign_keys='Transaction.sender_id',
                                      backref='sender', lazy=True)
    transactions_received = db.relationship('Transaction', foreign_keys='Transaction.recipient_id',
                                          backref='recipient', lazy=True)
    # Specify the foreign key for loans relationship
    loans = db.relationship('Loan', foreign_keys='Loan.business_id',
                          backref='business', lazy=True)
    # Add relationship for loans approved by admin
    loans_approved = db.relationship('Loan', foreign_keys='Loan.approved_by',
                                   backref='approved_by_admin', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @staticmethod
    def get_by_email(email):
        return User.query.filter_by(email=email).first()

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    recipient_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='completed')

class Loan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    business_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    type = db.Column(db.String(20), nullable=False)
    purpose = db.Column(db.String(200), nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    approved_at = db.Column(db.DateTime)
    approved_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    rejection_reason = db.Column(db.String(500))