let socket = io();
let chatHistory = [];

function initChat() {
    const chatbox = document.getElementById('chatbox');
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-message');

    sendButton.addEventListener('click', () => {
        const message = messageInput.value.trim();
        if (message) {
            appendMessage('user', message);
            socket.emit('send_message', { message: message });
            messageInput.value = '';
        }
    });

    socket.on('receive_message', (data) => {
        appendMessage('bot', data.response);
    });
}

function appendMessage(sender, message) {
    const chatbox = document.getElementById('chatbox');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    messageDiv.textContent = message;
    chatbox.appendChild(messageDiv);
    chatbox.scrollTop = chatbox.scrollHeight;
    
    if (sender === 'user') {
        chatHistory.push({ role: 'user', content: message });
    } else {
        chatHistory.push({ role: 'assistant', content: message });
    }
}

document.addEventListener('DOMContentLoaded', initChat);
