import requests
from config import Config

def get_chatbot_response(message, conversation_history=[]):
    headers = {
        'Authorization': f'Bearer {Config.PERPLEXITY_API_KEY}',
        'Content-Type': 'application/json'
    }

    messages = [
        {
            "role": "system",
            "content": "You are a helpful financial assistant. Provide concise and accurate information about banking, loans, and KYC processes."
        }
    ]

    # Add conversation history
    for msg in conversation_history:
        messages.append(msg)

    # Add current message
    messages.append({
        "role": "user",
        "content": message
    })

    data = {
        "model": "llama-3.1-sonar-small-128k-online",
        "messages": messages,
        "temperature": 0.2,
        "max_tokens": 150,
        "stream": False
    }

    try:
        response = requests.post(
            'https://api.perplexity.ai/chat/completions',
            headers=headers,
            json=data
        )
        response.raise_for_status()
        return response.json()['choices'][0]['message']['content']
    except Exception as e:
        return f"Sorry, I'm having trouble responding right now. Error: {str(e)}"
